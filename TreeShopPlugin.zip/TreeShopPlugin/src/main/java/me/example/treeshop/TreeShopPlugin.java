package me.example.treeshop;

import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;

public class TreeShopPlugin extends JavaPlugin implements CommandExecutor {

    private final Set<Material> saplings = Set.of(
            Material.OAK_SAPLING,
            Material.SPRUCE_SAPLING,
            Material.BIRCH_SAPLING,
            Material.JUNGLE_SAPLING,
            Material.ACACIA_SAPLING,
            Material.DARK_OAK_SAPLING,
            Material.CHERRY_SAPLING,
            Material.MANGROVE_PROPAGULE,
            Material.AZALEA,
            Material.FLOWERING_AZALEA
    );

    private final Map<Integer, ShopItem> shopItems = new HashMap<>();

    @Override
    public void onEnable() {

        Objects.requireNonNull(getCommand("shopsell")).setExecutor(this);
        Objects.requireNonNull(getCommand("shopbuy")).setExecutor(this);

        Bukkit.getPluginManager().registerEvents(new ShopListener(), this);

        loadShop();

        getLogger().info("TreeShop включён!");
    }

    private void loadShop() {

        int slot = 0;

        addItem(slot++, Material.DIAMOND, 8);
        addItem(slot++, Material.IRON_INGOT, 4);
        addItem(slot++, Material.GOLD_INGOT, 5);
        addItem(slot++, Material.EMERALD, 10);
        addItem(slot++, Material.COAL, 2);
        addItem(slot++, Material.QUARTZ, 3);
        addItem(slot++, Material.LAPIS_LAZULI, 3);
        addItem(slot++, Material.REDSTONE, 2);
        addItem(slot++, Material.COPPER_INGOT, 3);

        addItem(slot++, Material.SENTRY_ARMOR_TRIM_SMITHING_TEMPLATE, 25);
        addItem(slot++, Material.DUNE_ARMOR_TRIM_SMITHING_TEMPLATE, 25);
        addItem(slot++, Material.COAST_ARMOR_TRIM_SMITHING_TEMPLATE, 25);

        addEnchantBook(slot++, Enchantment.SHARPNESS, 5, 20);
        addEnchantBook(slot++, Enchantment.PROTECTION, 4, 18);
        addEnchantBook(slot++, Enchantment.EFFICIENCY, 5, 20);
        addEnchantBook(slot++, Enchantment.UNBREAKING, 3, 15);
        addEnchantBook(slot++, Enchantment.MENDING, 1, 40);
        addEnchantBook(slot++, Enchantment.FORTUNE, 3, 25);
    }

    private void addItem(int slot, Material material, int price) {
        ItemStack item = new ItemStack(material);

        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.GOLD + material.name());

        meta.setLore(List.of(ChatColor.YELLOW + "Цена: " + price + " монет"));
        item.setItemMeta(meta);

        shopItems.put(slot, new ShopItem(item, price));
    }

    private void addEnchantBook(int slot, Enchantment enchantment, int level, int price) {

        ItemStack book = new ItemStack(Material.ENCHANTED_BOOK);

        EnchantmentStorageMeta meta =
                (EnchantmentStorageMeta) book.getItemMeta();

        meta.addStoredEnchant(enchantment, level, true);

        meta.setDisplayName(ChatColor.AQUA +
                enchantment.getKey().getKey() + " " + level);

        meta.setLore(List.of(
                ChatColor.YELLOW + "Цена: " + price + " монет"
        ));

        book.setItemMeta(meta);

        shopItems.put(slot, new ShopItem(book, price));
    }

    @Override
    public boolean onCommand(CommandSender sender,
                             Command command,
                             String label,
                             String[] args) {

        if (!(sender instanceof Player player))
            return true;

        if (command.getName().equalsIgnoreCase("shopsell")) {

            int totalSaplings = 0;

            for (ItemStack item : player.getInventory().getContents()) {

                if (item == null)
                    continue;

                if (saplings.contains(item.getType())) {

                    totalSaplings += item.getAmount();

                    player.getInventory().remove(item);
                }
            }

            if (totalSaplings <= 0) {

                player.sendMessage(ChatColor.RED +
                        "У тебя нет саженцев!");
                return true;
            }

            ItemStack coins =
                    new ItemStack(Material.NETHER_STAR, totalSaplings);

            ItemMeta meta = coins.getItemMeta();
            meta.setDisplayName(ChatColor.GOLD + "Монета");
            coins.setItemMeta(meta);

            player.getInventory().addItem(coins);

            player.sendMessage(ChatColor.GREEN +
                    "Продано саженцев: " + totalSaplings);

            return true;
        }

        if (command.getName().equalsIgnoreCase("shopbuy")) {

            Inventory inv =
                    Bukkit.createInventory(null, 54,
                            ChatColor.DARK_GREEN + "Магазин");

            for (Map.Entry<Integer, ShopItem> entry :
                    shopItems.entrySet()) {

                inv.setItem(entry.getKey(),
                        entry.getValue().item());
            }

            player.openInventory(inv);

            return true;
        }

        return true;
    }

    public class ShopListener implements Listener, org.bukkit.event.Listener {

        @org.bukkit.event.EventHandler
        public void onClick(org.bukkit.event.inventory.InventoryClickEvent e) {

            if (e.getView().getTitle()
                    .equals(ChatColor.DARK_GREEN + "Магазин")) {

                e.setCancelled(true);

                if (!(e.getWhoClicked() instanceof Player player))
                    return;

                ItemStack clicked = e.getCurrentItem();

                if (clicked == null)
                    return;

                int slot = e.getSlot();

                if (!shopItems.containsKey(slot))
                    return;

                ShopItem shopItem = shopItems.get(slot);

                int price = shopItem.price();

                int coins = countCoins(player);

                if (coins < price) {

                    player.sendMessage(ChatColor.RED +
                            "Недостаточно монет!");
                    return;
                }

                removeCoins(player, price);

                player.getInventory().addItem(
                        shopItem.item().clone()
                );

                player.sendMessage(ChatColor.GREEN +
                        "Покупка успешна!");
            }
        }

        private int countCoins(Player player) {

            int amount = 0;

            for (ItemStack item :
                    player.getInventory().getContents()) {

                if (item == null)
                    continue;

                if (item.getType() == Material.NETHER_STAR)
                    amount += item.getAmount();
            }

            return amount;
        }

        private void removeCoins(Player player, int amount) {

            int left = amount;

            for (ItemStack item :
                    player.getInventory().getContents()) {

                if (item == null)
                    continue;

                if (item.getType() != Material.NETHER_STAR)
                    continue;

                if (item.getAmount() <= left) {

                    left -= item.getAmount();
                    item.setAmount(0);

                } else {

                    item.setAmount(item.getAmount() - left);
                    return;
                }
            }
        }
    }

    public record ShopItem(ItemStack item, int price) {}
}
